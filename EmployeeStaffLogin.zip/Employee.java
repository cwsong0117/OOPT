/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
import java.util.Scanner;

public class Employee {
    private String name;
    private String staffID;
    private String phoneNum;
    private String email;
    private int age;
    private String password;

    public Employee(String name, String staffID, String phoneNum, String email, int age, String password) {
        this.name = name;
        this.staffID = staffID;
        this.phoneNum = phoneNum;
        this.email = email;
        this.age = age;
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public String getStaffID() {
        return staffID;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public String getEmail() {
        return email;
    }

    public int getAge() {
        return age;
    }

    public String getPassword() {
        return password;
    }

    public static Employee signup() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter name: ");
        String name = scanner.nextLine();

        System.out.print("Enter staff ID: ");
        String staffID = scanner.nextLine();

        System.out.print("Enter phone number: ");
        String phoneNum = scanner.nextLine();

        System.out.print("Enter email: ");
        String email = scanner.nextLine();

        System.out.print("Enter age: ");
        int age = scanner.nextInt();
        scanner.nextLine();  // Consume the newline

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        return new Employee(name, staffID, phoneNum, email, age, password);
    }

    public String login(String staffID, String password) {
        if (this.staffID.equals(staffID) && this.password.equals(password)) {
            return "Login successful!";
        } else if (!this.staffID.equals(staffID)) {
            return "Staff ID does not match.";
        } else {
            return "Password is incorrect.";
        }
    }

    public void updateProfile() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Update name (current: " + this.name + "): ");
        this.name = scanner.nextLine();

        System.out.print("Update phone number (current: " + this.phoneNum + "): ");
        this.phoneNum = scanner.nextLine();

        System.out.print("Update email (current: " + this.email + "): ");
        this.email = scanner.nextLine();

        System.out.print("Update age (current: " + this.age + "): ");
        this.age = scanner.nextInt();
        scanner.nextLine();  // Consume the newline

        System.out.print("Update password: ");
        this.password = scanner.nextLine();

        System.out.println("Profile updated successfully!");
    }
}
